package com.santiparra.yomitrack.db.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.santiparra.yomitrack.db.entities.AnimeEntity;

import java.util.List;

/**
 * DAO para acceder y modificar animes en la base de datos.
 */
@Dao
public interface AnimeDao {

    /**
     * Inserta un nuevo anime.
     */
    @Insert
    void insertAnime(AnimeEntity anime);

    /**
     * Obtiene todos los animes registrados por un usuario.
     */
    @Query("SELECT * FROM anime WHERE userId = :userId")
    List<AnimeEntity> getAnimeByUser(int userId);

    /**
     * Elimina un anime.
     */
    @Delete
    void deleteAnime(AnimeEntity anime);

    /**
     * Busca un anime por su título.
     */
    @Query("SELECT * FROM anime WHERE userId = :userId AND title = :title LIMIT 1")
    AnimeEntity getAnimeByTitle(int userId, String title);

    /**
     * Actualiza un anime existente.
     */
    @Update
    void updateAnime(AnimeEntity anime);
}
