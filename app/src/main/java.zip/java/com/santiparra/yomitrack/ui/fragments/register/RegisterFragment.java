package com.santiparra.yomitrack.ui.fragments.register;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.santiparra.yomitrack.R;
import com.santiparra.yomitrack.db.AppDatabase;
import com.santiparra.yomitrack.db.entities.UserEntity;

/**
 * Fragmento para registrar nuevos usuarios en la base de datos local.
 */
public class RegisterFragment extends Fragment {

    private EditText usernameEditText, passwordEditText;
    private Button registerButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_register, container, false);

        usernameEditText = view.findViewById(R.id.editTextUsernameRegister);
        passwordEditText = view.findViewById(R.id.editTextPasswordRegister);
        registerButton = view.findViewById(R.id.buttonRegister);

        registerButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(getContext(), "Rellena todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            UserEntity newUser = new UserEntity();
            newUser.username = username;
            newUser.password = password;

            AppDatabase db = AppDatabase.getInstance(requireContext());
            db.userDao().insertUser(newUser);

            Toast.makeText(getContext(), "Registro exitoso", Toast.LENGTH_SHORT).show();
            NavHostFragment.findNavController(RegisterFragment.this).navigateUp();
        });

        return view;
    }
}
