package com.santiparra.yomitrack.db.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Entidad de manga para la base de datos
 */
public class MangaEntity {
    public int id;
    public int userId;
    public String title;
    public String status;
    public String imageUrl;
}
