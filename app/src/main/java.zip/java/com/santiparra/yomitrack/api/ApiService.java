package com.santiparra.yomitrack.api;

import com.santiparra.yomitrack.db.entities.AnimeEntity;
import com.santiparra.yomitrack.db.entities.MangaEntity;
import com.santiparra.yomitrack.db.entities.UserEntity;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface ApiService {
    @POST("users/register")
    Call<String> registerUser(@Body UserEntity user);

    @POST("users/login")
    Call<UserEntity> loginUser(@Body UserEntity user);

    @POST("anime/add")
    Call<String> insertAnime(@Body AnimeEntity anime);

    @GET("anime/list/{userId}")
    Call<List<AnimeEntity>> getAnimeByUser(@Path("userId") int userId);

    @DELETE("anime/delete/{id}")
    Call<String> deleteAnime(@Path("id") int id);

    @POST("manga/add")
    Call<String> insertManga(@Body MangaEntity manga);

    @GET("manga/list/{userId}")
    Call<List<MangaEntity>> getMangaByUser(@Path("userId") int userId);

    @DELETE("manga/delete/{id}")
    Call<String> deleteManga(@Path("id") int id);

    @GET("anilist/anime/{id}")
    Call<Object> getAnimeFromAniList(@Path("id") int animeId);
}

