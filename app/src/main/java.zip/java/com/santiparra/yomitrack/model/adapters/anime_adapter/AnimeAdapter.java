package com.santiparra.yomitrack.model.adapters.anime_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.santiparra.yomitrack.R;
import com.santiparra.yomitrack.model.AnimeItem;

import java.util.List;

/**
 * Adaptador personalizado para mostrar elementos de anime en una RecyclerView.
 * Soporta distintos modos de vista, edición y eliminación de ítems.
 */
public class AnimeAdapter extends RecyclerView.Adapter<AnimeAdapter.AnimeViewHolder> {

    private final List<AnimeItem> animeList;
    private final Context context;
    private int viewMode = 0;

    /** Listener para eliminar un anime */
    public interface OnAnimeRemoveListener {
        void onAnimeRemoved(AnimeItem anime);
    }

    /** Listener para editar un anime */
    public interface OnAnimeEditListener {
        void onAnimeEdit(AnimeItem anime);
    }

    private OnAnimeRemoveListener removeListener;
    private OnAnimeEditListener editListener;

    /** Establece el listener de eliminación */
    public void setOnAnimeRemoveListener(OnAnimeRemoveListener listener) {
        this.removeListener = listener;
    }

    /** Establece el listener de edición */
    public void setOnAnimeEditListener(OnAnimeEditListener listener) {
        this.editListener = listener;
    }

    /** Establece el modo de visualización */
    public void setViewMode(int mode) {
        this.viewMode = mode;
    }

    public AnimeAdapter(Context context, List<AnimeItem> animeList) {
        this.context = context;
        this.animeList = animeList;
    }

    @NonNull
    @Override
    public AnimeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layoutId;
        switch (viewMode) {
            case 1:
                layoutId = R.layout.item_anime_large;
                break;
            case 2:
                layoutId = R.layout.item_anime_compact;
                break;
            default:
                layoutId = R.layout.item_anime;
                break;
        }
        View view = LayoutInflater.from(context).inflate(layoutId, parent, false);
        return new AnimeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AnimeViewHolder holder, int position) {
        AnimeItem anime = animeList.get(position);

        // Bind de datos a las vistas
        if (holder.title != null) holder.title.setText(anime.getTitle());
        if (holder.progress != null)
            holder.progress.setText("Progress: " + anime.getWatchedEpisodes() + "/" + anime.getTotalEpisodes());
        if (holder.score != null) holder.score.setText(String.valueOf(anime.getScore()));
        if (holder.type != null) holder.type.setText(anime.getType());

        if (holder.cover != null) {
            Glide.with(context)
                    .load(anime.getImageUrl())
                    .placeholder(R.drawable.sample_anime_cover)
                    .into(holder.cover);
        }

        // Menú contextual por ítem
        if (holder.buttonOptions != null) {
            holder.buttonOptions.setOnClickListener(v -> {
                PopupMenu popup = new PopupMenu(context, holder.buttonOptions);
                popup.inflate(R.menu.anime_item_menu);
                popup.setOnMenuItemClickListener(item -> {
                    int id = item.getItemId();
                    if (id == R.id.action_edit && editListener != null) {
                        editListener.onAnimeEdit(anime);
                        return true;
                    } else if (id == R.id.action_remove && removeListener != null) {
                        int pos = holder.getAdapterPosition();
                        if (pos != RecyclerView.NO_POSITION) {
                            AnimeItem removed = animeList.remove(pos);
                            notifyItemRemoved(pos);
                            removeListener.onAnimeRemoved(removed);
                            Toast.makeText(context, "Removed: " + removed.getTitle(), Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    }
                    return false;
                });
                popup.show();
            });
        }
    }

    @Override
    public int getItemCount() {
        return animeList.size();
    }

    /** ViewHolder para ítems de anime */
    static class AnimeViewHolder extends RecyclerView.ViewHolder {
        TextView title, progress, score, type;
        ImageView cover, buttonOptions;

        AnimeViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.textViewTitle);
            progress = itemView.findViewById(R.id.textViewProgress);
            score = itemView.findViewById(R.id.textViewScore);
            type = itemView.findViewById(R.id.textViewType);
            cover = itemView.findViewById(R.id.imageViewCover);
            buttonOptions = itemView.findViewById(R.id.buttonOptions);
        }
    }
}
