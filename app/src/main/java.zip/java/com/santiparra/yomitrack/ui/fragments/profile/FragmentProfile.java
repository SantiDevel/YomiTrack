package com.santiparra.yomitrack.ui.fragments.profile;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Button;
import androidx.fragment.app.Fragment;

import com.santiparra.yomitrack.R;
import com.santiparra.yomitrack.api.ApiClient;
import com.santiparra.yomitrack.api.ApiService;
import com.santiparra.yomitrack.db.entities.AnimeEntity;
import com.santiparra.yomitrack.db.entities.MangaEntity;
import com.santiparra.yomitrack.db.entities.UserEntity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentProfile extends Fragment {

    private LinearLayout animeStatsContainer, mangaStatsContainer, activityContainer;
    private ImageView avatarImage, coverImage;
    private TextView usernameText;
    private EditText editBiography, editStatus;
    private Button buttonSaveBio, buttonPostStatus;

    private UserEntity currentUser;

    public FragmentProfile() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        animeStatsContainer = view.findViewById(R.id.animeStatsContainer);
        mangaStatsContainer = view.findViewById(R.id.mangaStatsContainer);
        activityContainer = view.findViewById(R.id.activityContainer);
        avatarImage = view.findViewById(R.id.avatarImage);
        coverImage = view.findViewById(R.id.coverImage);
        usernameText = view.findViewById(R.id.usernameText);
        editBiography = view.findViewById(R.id.editBiography);
        editStatus = view.findViewById(R.id.editStatus);
        buttonSaveBio = view.findViewById(R.id.buttonSaveBio);
        buttonPostStatus = view.findViewById(R.id.buttonPostStatus);

        currentUser = getCurrentUserFromPreferences(requireContext());
        usernameText.setText(currentUser.getUsername());
        avatarImage.setImageResource(R.drawable.ic_profile);
        coverImage.setImageResource(R.drawable.sample_cover);

        buttonPostStatus.setOnClickListener(v -> {
            String status = editStatus.getText().toString();
            if (!status.isEmpty()) {
                addActivityEntry("Publicó un estado:", status, "");
                editStatus.setText("");
            }
        });

        return view;
    }

    private UserEntity getCurrentUserFromPreferences(Context context) {
        SharedPreferences prefs = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE);
        int userId = prefs.getInt("user_id", -1);
        return new UserEntity();
    }

    @Override
    public void onResume() {
        super.onResume();
        fetchAnimeStats();
        fetchMangaStats();
    }

    private void fetchAnimeStats() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<List<AnimeEntity>> call = apiService.getAnimeByUser(currentUser.getId());

        call.enqueue(new Callback<List<AnimeEntity>>() {
            @Override
            public void onResponse(Call<List<AnimeEntity>> call, Response<List<AnimeEntity>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    updateAnimeStats(response.body());
                }
            }

            @Override
            public void onFailure(Call<List<AnimeEntity>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void fetchMangaStats() {
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<List<MangaEntity>> call = apiService.getMangaByUser(currentUser.getId());

        call.enqueue(new Callback<List<MangaEntity>>() {
            @Override
            public void onResponse(Call<List<MangaEntity>> call, Response<List<MangaEntity>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    updateMangaStats(response.body());
                }
            }

            @Override
            public void onFailure(Call<List<MangaEntity>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    public void updateAnimeStats(List<AnimeEntity> animeList) {
        animeStatsContainer.removeAllViews();
        Map<String, Integer> statusCount = new HashMap<>();
        int total = animeList.size();
        for (AnimeEntity anime : animeList) {
            String status = anime.getStatus();
            statusCount.put(status, statusCount.getOrDefault(status, 0) + 1);
        }
        for (Map.Entry<String, Integer> entry : statusCount.entrySet()) {
            View statView = LayoutInflater.from(getContext()).inflate(R.layout.item_stat_bar, animeStatsContainer, false);
            TextView label = statView.findViewById(R.id.statLabelFull);
            ProgressBar bar = statView.findViewById(R.id.statProgressBar);
            label.setText(entry.getKey() + " • " + entry.getValue());
            bar.setProgress((int) ((entry.getValue() / (float) total) * 100));
            animeStatsContainer.addView(statView);
        }
    }

    public void updateMangaStats(List<MangaEntity> mangaList) {
        mangaStatsContainer.removeAllViews();
        Map<String, Integer> statusCount = new HashMap<>();
        int total = mangaList.size();
        for (MangaEntity manga : mangaList) {
            String status = manga.getStatus();
            statusCount.put(status, statusCount.getOrDefault(status, 0) + 1);
        }
        for (Map.Entry<String, Integer> entry : statusCount.entrySet()) {
            View statView = LayoutInflater.from(getContext()).inflate(R.layout.item_stat_bar, mangaStatsContainer, false);
            TextView label = statView.findViewById(R.id.statLabelFull);
            ProgressBar bar = statView.findViewById(R.id.statProgressBar);
            label.setText(entry.getKey() + " • " + entry.getValue());
            bar.setProgress((int) ((entry.getValue() / (float) total) * 100));
            mangaStatsContainer.addView(statView);
        }
    }

    public void addActivityEntry(String action, String title, String coverUrl) {
        View activityView = LayoutInflater.from(getContext()).inflate(R.layout.item_activity, activityContainer, false);
        TextView text = activityView.findViewById(R.id.activityText);
        TextView time = activityView.findViewById(R.id.activityTime);
        ImageView thumbnail = activityView.findViewById(R.id.activityThumbnail);

        text.setText(action + " " + title);
        time.setText(getCurrentTimeString());
        thumbnail.setImageResource(R.drawable.sample_cover);

        activityContainer.addView(activityView, 0);
    }

    private String getCurrentTimeString() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm, dd MMM", Locale.getDefault());
        return sdf.format(new Date());
    }

    public void refreshUser(UserEntity user) {
        this.currentUser = user;
        usernameText.setText(user.getUsername());
        avatarImage.setImageResource(R.drawable.ic_profile);
        coverImage.setImageResource(R.drawable.sample_cover);
    }
}
