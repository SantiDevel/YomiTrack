package com.santiparra.yomitrack.model;

public class CommentModel {
    public String text;
    public boolean liked;

    public CommentModel(String text) {
        this.text = text;
        this.liked = false;
    }
}
