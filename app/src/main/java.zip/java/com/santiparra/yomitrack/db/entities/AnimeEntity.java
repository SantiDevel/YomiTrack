package com.santiparra.yomitrack.db.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Entidad que representa un anime guardado por el usuario en la base de datos
 */
public class AnimeEntity {
    public int id;
    public int userId;
    public String title;
    public String status;
    public String imageUrl;
}
