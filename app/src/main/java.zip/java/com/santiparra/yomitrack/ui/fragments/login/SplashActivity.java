package com.santiparra.yomitrack.ui.fragments.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.santiparra.yomitrack.ui.MainActivity;

/**
 * Actividad inicial que decide si ir a LoginActivity o directamente a MainActivity.
 */
public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);
        int userId = prefs.getInt("current_user_id", -1);

        if (userId == -1) {
            // No logueado
            startActivity(new Intent(this, LoginActivity.class));
        } else {
            // Logueado
            startActivity(new Intent(this, MainActivity.class));
        }

        finish(); // cerrar splash
    }
}
