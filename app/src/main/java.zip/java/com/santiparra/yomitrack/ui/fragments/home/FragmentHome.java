// FragmentHome.java
package com.santiparra.yomitrack.ui.fragments.home;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.JsonObject;
import com.santiparra.yomitrack.R;
import com.santiparra.yomitrack.api.ApiClient;
import com.santiparra.yomitrack.api.ApiService;
import com.santiparra.yomitrack.db.entities.AnimeEntity;
import com.santiparra.yomitrack.db.entities.MangaEntity;
import com.santiparra.yomitrack.model.ItemModel;
import com.santiparra.yomitrack.model.RecentActivityModel;
import com.santiparra.yomitrack.model.adapters.homeadapter.HomeCardAdapter;
import com.santiparra.yomitrack.model.adapters.recentactivity_adapter.RecentActivityAdapter;
import com.santiparra.yomitrack.ui.fragments.editanime.EditAnimeFragment;
import com.santiparra.yomitrack.ui.fragments.editmanga.EditMangaFragment;
import com.santiparra.yomitrack.utils.ActivityLog;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FragmentHome extends Fragment {

    private RecyclerView recyclerAnime, recyclerManga, recyclerActivity;
    private EditText inputStatus;
    private Button btnPost;
    private RecentActivityAdapter activityAdapter;
    private ApiService api;
    private int userId;

    public FragmentHome() {
        super(R.layout.fragment_home);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerAnime = view.findViewById(R.id.recyclerAnime);
        recyclerManga = view.findViewById(R.id.recyclerManga);
        recyclerActivity = view.findViewById(R.id.activityRecyclerView);
        inputStatus = view.findViewById(R.id.inputStatus);
        btnPost = view.findViewById(R.id.btnPost);

        recyclerActivity.setLayoutManager(new LinearLayoutManager(getContext()));
        activityAdapter = new RecentActivityAdapter(new ArrayList<>());
        recyclerActivity.setAdapter(activityAdapter);

        SharedPreferences prefs = requireContext().getSharedPreferences("user_session", Context.MODE_PRIVATE);
        userId = prefs.getInt("user_id", -1);

        if (userId == -1) return;

        api = ApiClient.getClient().create(ApiService.class);

        btnPost.setOnClickListener(v -> postThought());

        loadAnimeSection();
        loadMangaSection();
        loadActivityLog();
    }

    private void loadAnimeSection() {
        api.getAnimeByUserAndStatus(userId, "Watching").enqueue(new Callback<List<AnimeEntity>>() {
            @Override
            public void onResponse(Call<List<AnimeEntity>> call, Response<List<AnimeEntity>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<ItemModel> items = new ArrayList<>();
                    for (int i = 0; i < Math.min(10, response.body().size()); i++) {
                        AnimeEntity anime = response.body().get(i);
                        items.add(new ItemModel(anime.getTitle(), anime.getProgress() + "/" + anime.getTotalEpisodes(), anime.getImageUrl(), ItemModel.ContentType.ANIME, anime));
                    }

                    HomeCardAdapter adapter = new HomeCardAdapter(items, item -> {
                        EditAnimeFragment fragment = new EditAnimeFragment((AnimeEntity) item.getObject());
                        requireActivity().getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.frame_layout, fragment)
                                .addToBackStack(null)
                                .commit();
                    });

                    recyclerAnime.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
                    recyclerAnime.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<List<AnimeEntity>> call, Throwable t) {
            }
        });
    }

    private void loadMangaSection() {
        api.getMangaByUserAndStatus(userId, "Reading").enqueue(new Callback<List<MangaEntity>>() {
            @Override
            public void onResponse(Call<List<MangaEntity>> call, Response<List<MangaEntity>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<ItemModel> items = new ArrayList<>();
                    for (int i = 0; i < Math.min(10, response.body().size()); i++) {
                        MangaEntity manga = response.body().get(i);
                        items.add(new ItemModel(manga.getTitle(), manga.getProgress() + "/" + manga.getTotalChapters(), manga.getImageUrl(), ItemModel.ContentType.MANGA, manga));
                    }

                    HomeCardAdapter adapter = new HomeCardAdapter(items, item -> {
                        EditMangaFragment fragment = new EditMangaFragment((MangaEntity) item.getObject());
                        requireActivity().getSupportFragmentManager()
                                .beginTransaction()
                                .replace(R.id.frame_layout, fragment)
                                .addToBackStack(null)
                                .commit();
                    });

                    recyclerManga.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
                    recyclerManga.setAdapter(adapter);
                }
            }

            @Override
            public void onFailure(Call<List<MangaEntity>> call, Throwable t) {
            }
        });
    }

    private void loadActivityLog() {
        api.getActivityLog(userId).enqueue(new Callback<List<ActivityLog>>() {
            @Override
            public void onResponse(Call<List<ActivityLog>> call, Response<List<ActivityLog>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<RecentActivityModel> recentList = new ArrayList<>();
                    for (ActivityLog log : response.body()) {
                        RecentActivityModel model = new RecentActivityModel(
                                log.getId(),
                                log.getUserId(),
                                log.getUsername(), // ← usamos el nombre
                                log.getAction(),
                                log.getMediaTitle(),
                                log.getImageUrl(),
                                log.getTimestamp(),
                                new ArrayList<>(),
                                false
                        );
                        recentList.add(model);
                    }
                    activityAdapter.updateData(recentList);
                }
            }

            @Override
            public void onFailure(Call<List<ActivityLog>> call, Throwable t) {
                Toast.makeText(getContext(), "Error al cargar actividad", Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void postThought() {
        String status = inputStatus.getText().toString().trim();
        if (TextUtils.isEmpty(status)) {
            Toast.makeText(getContext(), "Escribe algo", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> post = new HashMap<>();
        post.put("userId", userId);
        post.put("action", "publicó");
        post.put("mediaTitle", status);

        api.postActivity(post).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    inputStatus.setText("");
                    loadActivityLog();
                    Toast.makeText(getContext(), "Publicado", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Toast.makeText(getContext(), "Error al publicar", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
