package com.santiparra.yomitrack.utils;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.*;

public class ActivityLogger {

    private static final String PREF_NAME = "user_profile";
    private static final String KEY_ACTIVITIES = "recent_activities";

    public static void log(Context context, String message) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        List<ActivityItem> items = getActivities(context);
        items.add(0, new ActivityItem(message, System.currentTimeMillis()));
        if (items.size() > 30) items = items.subList(0, 30);
        saveActivities(prefs, items);
    }

    public static List<ActivityItem> getActivities(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(KEY_ACTIVITIES, "[]");
        return new Gson().fromJson(json, new TypeToken<List<ActivityItem>>(){}.getType());
    }

    private static void saveActivities(SharedPreferences prefs, List<ActivityItem> items) {
        String json = new Gson().toJson(items);
        prefs.edit().putString(KEY_ACTIVITIES, json).apply();
    }

    public static class ActivityItem {
        public String text;
        public long timestamp;

        public ActivityItem(String text, long timestamp) {
            this.text = text;
            this.timestamp = timestamp;
        }

        public String getRelativeTime() {
            long now = System.currentTimeMillis();
            long diff = now - timestamp;
            long minutes = diff / 60000;
            if (minutes < 1) return "Just now";
            if (minutes < 60) return minutes + " min ago";
            long hours = minutes / 60;
            if (hours < 24) return hours + "h ago";
            long days = hours / 24;
            return days + "d ago";
        }
    }
}
