package com.santiparra.yomitrack.db.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.santiparra.yomitrack.db.entities.MangaEntity;

import java.util.List;

/**
 * DAO para acceder y modificar mangas en la base de datos.
 */
@Dao
public interface MangaDao {

    /**
     * Inserta un nuevo manga.
     */
    @Insert
    void insertManga(MangaEntity manga);

    /**
     * Obtiene todos los mangas registrados por un usuario.
     */
    @Query("SELECT * FROM manga WHERE userId = :userId")
    List<MangaEntity> getMangaByUser(int userId);

    /**
     * Elimina un manga.
     */
    @Delete
    void deleteManga(MangaEntity manga);

    /**
     * Busca un manga por su título.
     */
    @Query("SELECT * FROM manga WHERE userId = :userId AND title = :title LIMIT 1")
    MangaEntity getMangaByTitle(int userId, String title);

    /**
     * Actualiza un manga existente.
     */
    @Update
    void updateManga(MangaEntity manga);
}
