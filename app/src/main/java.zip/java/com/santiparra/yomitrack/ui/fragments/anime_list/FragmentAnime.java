package com.santiparra.yomitrack.ui.fragments.anime_list;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.santiparra.yomitrack.R;

import com.santiparra.yomitrack.db.AppDatabase;
import com.santiparra.yomitrack.db.entities.AnimeEntity;
import com.santiparra.yomitrack.model.AnimeItem;
import com.santiparra.yomitrack.model.adapters.anime_adapter.AnimeAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Fragmento encargado de mostrar, filtrar y administrar la lista de anime del usuario.
 * Permite añadir, editar y eliminar animes usando Room y una RecyclerView adaptable.
 */
public class FragmentAnime extends Fragment {

    // UI
    private RecyclerView recyclerView;
    private EditText editTextFilter;
    private TextView textViewTitle;
    private AnimeAdapter adapter;
    private ImageButton buttonGrid, buttonLarge, buttonList;

    // Datos
    private final List<AnimeItem> fullAnimeList = new ArrayList<>();
    private final List<AnimeItem> filteredAnimeList = new ArrayList<>();
    private String currentStatus = "Watching";
    private int currentViewMode = 0;

    /**
     * Infla el layout y configura listeners, adapter y filtros.
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_alist, container, false);

        // Referencias UI
        recyclerView = view.findViewById(R.id.recyclerViewAnimeList);
        editTextFilter = view.findViewById(R.id.editTextFilter);
        textViewTitle = view.findViewById(R.id.textViewWatching);
        ImageView buttonFilterMenu = view.findViewById(R.id.buttonFilterMenu);
        buttonGrid = view.findViewById(R.id.buttonViewGrid);
        buttonLarge = view.findViewById(R.id.buttonViewLarge);
        buttonList = view.findViewById(R.id.buttonViewList);

        // Modo de vista
        buttonGrid.setOnClickListener(v -> setLayoutMode(0));
        buttonLarge.setOnClickListener(v -> setLayoutMode(1));
        buttonList.setOnClickListener(v -> setLayoutMode(2));

        // Cargar datos desde Room
        loadAnimeFromDatabase();

        // Inicializar adapter
        adapter = new AnimeAdapter(getContext(), filteredAnimeList);
        adapter.setViewMode(currentViewMode);
        recyclerView.setAdapter(adapter);

        // Eliminar anime
        adapter.setOnAnimeRemoveListener(animeItem -> {
            SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
            int userId = prefs.getInt("current_user_id", -1);
            AppDatabase db = AppDatabase.getInstance(requireContext());
            AnimeEntity entity = db.animeDao().getAnimeByTitle(userId, animeItem.getTitle());
            if (entity != null) db.animeDao().deleteAnime(entity);
            fullAnimeList.remove(animeItem);
            filterAnimeList(editTextFilter.getText().toString());
        });

        // Editar anime
        adapter.setOnAnimeEditListener(this::showEditAnimeDialog);

        // Filtrar por texto
        editTextFilter.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterAnimeList(s.toString());
            }
        });

        // Mapa de estados
        Map<Integer, String> filterMap = new HashMap<>();
        filterMap.put(R.id.filter_all, "All");
        filterMap.put(R.id.filter_watching, "Watching");
        filterMap.put(R.id.filter_planning, "Planning");
        filterMap.put(R.id.filter_paused, "Paused");
        filterMap.put(R.id.filter_dropped, "Dropped");
        filterMap.put(R.id.filter_completed, "Completed");

        // Menú de filtros por estado
        buttonFilterMenu.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(requireContext(), buttonFilterMenu);
            popup.inflate(R.menu.filter_list_menu);
            popup.setOnMenuItemClickListener(item -> {
                String selectedStatus = filterMap.get(item.getItemId());
                if (selectedStatus != null) {
                    currentStatus = selectedStatus;
                    textViewTitle.setText(currentStatus);
                    filterAnimeList(editTextFilter.getText().toString());
                    return true;
                }
                return false;
            });
            popup.show();
        });

        // Botón añadir nuevo
        Button addButton = view.findViewById(R.id.buttonAddItem);
        addButton.setOnClickListener(v -> showAddAnimeDialog());

        // Aplicar layout por defecto
        setLayoutMode(currentViewMode);

        return view;
    }

    /**
     * Muestra un diálogo para añadir un nuevo anime a la lista.
     */
    private void showAddAnimeDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Añadir nuevo anime");

        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(16, 16, 16, 16);

        EditText inputTitle = new EditText(requireContext());
        inputTitle.setHint("Título");
        layout.addView(inputTitle);

        EditText inputStatus = new EditText(requireContext());
        inputStatus.setHint("Estado");
        layout.addView(inputStatus);

        EditText inputType = new EditText(requireContext());
        inputType.setHint("Tipo");
        layout.addView(inputType);

        EditText inputImageUrl = new EditText(requireContext());
        inputImageUrl.setHint("URL de imagen");
        layout.addView(inputImageUrl);

        builder.setView(layout);

        builder.setPositiveButton("Guardar", (dialog, which) -> {
            String title = inputTitle.getText().toString();
            String status = inputStatus.getText().toString();
            String type = inputType.getText().toString();
            String imageUrl = inputImageUrl.getText().toString();

            SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
            int userId = prefs.getInt("current_user_id", -1);

            AnimeEntity anime = new AnimeEntity();
            anime.userId = userId;
            anime.title = title;
            anime.status = status;
            anime.imageUrl = imageUrl;

            AppDatabase.getInstance(requireContext()).animeDao().insertAnime(anime);
            loadAnimeFromDatabase();
            filterAnimeList(editTextFilter.getText().toString());
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    /**
     * Muestra un diálogo para editar un anime existente.
     */
    private void showEditAnimeDialog(AnimeItem animeItem) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Editar anime");

        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(16, 16, 16, 16);

        EditText inputTitle = new EditText(requireContext());
        inputTitle.setHint("Título");
        inputTitle.setText(animeItem.getTitle());
        layout.addView(inputTitle);

        EditText inputStatus = new EditText(requireContext());
        inputStatus.setHint("Estado");
        inputStatus.setText(animeItem.getStatus());
        layout.addView(inputStatus);

        EditText inputType = new EditText(requireContext());
        inputType.setHint("Tipo");
        inputType.setText(animeItem.getType());
        layout.addView(inputType);

        EditText inputImageUrl = new EditText(requireContext());
        inputImageUrl.setHint("URL de imagen");
        inputImageUrl.setText(animeItem.getImageUrl());
        layout.addView(inputImageUrl);

        builder.setView(layout);

        builder.setPositiveButton("Guardar", (dialog, which) -> {
            animeItem.setTitle(inputTitle.getText().toString());
            animeItem.setStatus(inputStatus.getText().toString());
            animeItem.setType(inputType.getText().toString());
            animeItem.setImageUrl(inputImageUrl.getText().toString());

            SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
            int userId = prefs.getInt("current_user_id", -1);

            AnimeEntity updated = AppDatabase.getInstance(requireContext()).animeDao().getAnimeByTitle(userId, animeItem.getTitle());
            if (updated != null) {
                updated.title = animeItem.getTitle();
                updated.status = animeItem.getStatus();
                updated.imageUrl = animeItem.getImageUrl();
                AppDatabase.getInstance(requireContext()).animeDao().updateAnime(updated);
                loadAnimeFromDatabase();
                filterAnimeList(editTextFilter.getText().toString());
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    /**
     * Aplica filtro por estado y búsqueda textual.
     */
    private void filterAnimeList(String query) {
        filteredAnimeList.clear();
        int count = 0;
        for (AnimeItem anime : fullAnimeList) {
            boolean matchesStatus = currentStatus.equals("All") || anime.getStatus().equalsIgnoreCase(currentStatus);
            boolean matchesQuery = anime.getTitle().toLowerCase().contains(query.toLowerCase());
            if (matchesStatus && matchesQuery) {
                filteredAnimeList.add(anime);
                count++;
                if (count >= 10) {
                    Toast.makeText(requireContext(), "Mostrando los primeros 10 resultados", Toast.LENGTH_SHORT).show();
                    break;
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    /**
     * Cambia el modo de vista del RecyclerView: lista, grande, compacta.
     */
    private void setLayoutMode(int mode) {
        currentViewMode = mode;

        if (mode == 2) {
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        } else if (mode == 1) {
            recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 1));
        } else {
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        }

        adapter = new AnimeAdapter(getContext(), filteredAnimeList);
        adapter.setViewMode(mode);
        adapter.setOnAnimeRemoveListener(animeItem -> {
            SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
            int userId = prefs.getInt("current_user_id", -1);
            AppDatabase db = AppDatabase.getInstance(requireContext());
            AnimeEntity entity = db.animeDao().getAnimeByTitle(userId, animeItem.getTitle());
            if (entity != null) db.animeDao().deleteAnime(entity);
            fullAnimeList.remove(animeItem);
            filterAnimeList(editTextFilter.getText().toString());
        });
        adapter.setOnAnimeEditListener(this::showEditAnimeDialog);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        int defaultTint = ContextCompat.getColor(requireContext(), R.color.textPrimary);
        int activeTint = ContextCompat.getColor(requireContext(), R.color.activeTint);

        buttonGrid.setColorFilter(mode == 0 ? activeTint : defaultTint);
        buttonLarge.setColorFilter(mode == 1 ? activeTint : defaultTint);
        buttonList.setColorFilter(mode == 2 ? activeTint : defaultTint);
    }

    /**
     * Carga todos los animes del usuario desde la base de datos.
     */
    private void loadAnimeFromDatabase() {
        fullAnimeList.clear();

        SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        int userId = prefs.getInt("current_user_id", -1);

        List<AnimeEntity> entities = AppDatabase.getInstance(requireContext()).animeDao().getAnimeByUser(userId);

        for (AnimeEntity e : entities) {
            fullAnimeList.add(new AnimeItem(e.title, e.imageUrl, 0, 0, 0, "TV", e.status));
        }

        filteredAnimeList.clear();
        filteredAnimeList.addAll(fullAnimeList);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("currentStatus", currentStatus);
    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        if (savedInstanceState != null) {
            currentStatus = savedInstanceState.getString("currentStatus", "Watching");
            textViewTitle.setText(currentStatus);
            filterAnimeList(editTextFilter.getText().toString());
        }
    }
}
