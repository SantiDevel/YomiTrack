package com.santiparra.yomitrack.ui.fragments.manga_list;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.santiparra.yomitrack.R;
import com.santiparra.yomitrack.db.AppDatabase;
import com.santiparra.yomitrack.model.AnimeItem;
import com.santiparra.yomitrack.db.entities.MangaEntity;
import com.santiparra.yomitrack.model.adapters.manga_adapter.MangaAdapter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Fragmento encargado de mostrar, filtrar y administrar la lista de mangas del usuario.
 * Permite añadir, editar y eliminar mangas usando Room y una RecyclerView adaptable.
 */
public class FragmentManga extends Fragment {

    // UI
    private RecyclerView recyclerView;
    private EditText editTextFilter;
    private TextView textViewTitle;
    private MangaAdapter adapter;
    private ImageButton buttonGrid, buttonLarge, buttonList;

    // Datos
    private final List<AnimeItem> fullMangaList = new ArrayList<>();
    private final List<AnimeItem> filteredMangaList = new ArrayList<>();
    private String currentStatus = "Reading";
    private int currentViewMode = 0;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_mlist, container, false);

        // Referencias UI
        recyclerView = view.findViewById(R.id.recyclerViewAnimeList);
        editTextFilter = view.findViewById(R.id.editTextFilter);
        textViewTitle = view.findViewById(R.id.textViewWatching);
        ImageView buttonFilterMenu = view.findViewById(R.id.buttonFilterMenu);
        buttonGrid = view.findViewById(R.id.buttonViewGrid);
        buttonLarge = view.findViewById(R.id.buttonViewLarge);
        buttonList = view.findViewById(R.id.buttonViewList);

        // Modo de vista
        buttonGrid.setOnClickListener(v -> setLayoutMode(0));
        buttonLarge.setOnClickListener(v -> setLayoutMode(1));
        buttonList.setOnClickListener(v -> setLayoutMode(2));

        // Cargar datos desde Room
        loadMangaFromDatabase();

        // Inicializar adapter
        adapter = new MangaAdapter(getContext(), filteredMangaList);
        adapter.setViewMode(currentViewMode);
        recyclerView.setAdapter(adapter);

        // Eliminar manga
        adapter.setOnMangaRemoveListener(mangaItem -> {
            SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
            int userId = prefs.getInt("current_user_id", -1);
            AppDatabase db = AppDatabase.getInstance(requireContext());
            MangaEntity entity = db.mangaDao().getMangaByTitle(userId, mangaItem.getTitle());
            if (entity != null) db.mangaDao().deleteManga(entity);
            fullMangaList.remove(mangaItem);
            filterMangaList(editTextFilter.getText().toString());
        });

        // Editar manga
        adapter.setOnMangaEditListener(this::showEditMangaDialog);

        // Filtrar por texto
        editTextFilter.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterMangaList(s.toString());
            }
        });

        // Filtros por estado
        Map<Integer, String> filterMap = new HashMap<>();
        filterMap.put(R.id.filter_all, "All");
        filterMap.put(R.id.filter_watching, "Reading");
        filterMap.put(R.id.filter_planning, "Planning");
        filterMap.put(R.id.filter_paused, "Paused");
        filterMap.put(R.id.filter_dropped, "Dropped");
        filterMap.put(R.id.filter_completed, "Completed");

        buttonFilterMenu.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(requireContext(), buttonFilterMenu);
            popup.inflate(R.menu.filter_list_menu);
            popup.setOnMenuItemClickListener(item -> {
                String selectedStatus = filterMap.get(item.getItemId());
                if (selectedStatus != null) {
                    currentStatus = selectedStatus;
                    textViewTitle.setText(currentStatus);
                    filterMangaList(editTextFilter.getText().toString());
                    return true;
                }
                return false;
            });
            popup.show();
        });

        // Botón añadir nuevo
        Button addButton = view.findViewById(R.id.buttonAddItem);
        addButton.setOnClickListener(v -> showAddMangaDialog());

        setLayoutMode(currentViewMode);

        return view;
    }

    /**
     * Diálogo para añadir nuevo manga.
     */
    private void showAddMangaDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Añadir nuevo manga");

        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(16, 16, 16, 16);

        EditText inputTitle = new EditText(requireContext());
        inputTitle.setHint("Título");
        layout.addView(inputTitle);

        EditText inputStatus = new EditText(requireContext());
        inputStatus.setHint("Estado");
        layout.addView(inputStatus);

        EditText inputType = new EditText(requireContext());
        inputType.setHint("Tipo");
        layout.addView(inputType);

        EditText inputImageUrl = new EditText(requireContext());
        inputImageUrl.setHint("URL de imagen");
        layout.addView(inputImageUrl);

        builder.setView(layout);

        builder.setPositiveButton("Guardar", (dialog, which) -> {
            String title = inputTitle.getText().toString();
            String status = inputStatus.getText().toString();
            String type = inputType.getText().toString();
            String imageUrl = inputImageUrl.getText().toString();

            SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
            int userId = prefs.getInt("current_user_id", -1);

            MangaEntity manga = new MangaEntity();
            manga.userId = userId;
            manga.title = title;
            manga.status = status;
            manga.imageUrl = imageUrl;

            AppDatabase.getInstance(requireContext()).mangaDao().insertManga(manga);
            loadMangaFromDatabase();
            filterMangaList(editTextFilter.getText().toString());
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    /**
     * Diálogo para editar manga existente.
     */
    private void showEditMangaDialog(AnimeItem mangaItem) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Editar manga");

        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(16, 16, 16, 16);

        EditText inputTitle = new EditText(requireContext());
        inputTitle.setHint("Título");
        inputTitle.setText(mangaItem.getTitle());
        layout.addView(inputTitle);

        EditText inputStatus = new EditText(requireContext());
        inputStatus.setHint("Estado");
        inputStatus.setText(mangaItem.getStatus());
        layout.addView(inputStatus);

        EditText inputType = new EditText(requireContext());
        inputType.setHint("Tipo");
        inputType.setText(mangaItem.getType());
        layout.addView(inputType);

        EditText inputImageUrl = new EditText(requireContext());
        inputImageUrl.setHint("URL de imagen");
        inputImageUrl.setText(mangaItem.getImageUrl());
        layout.addView(inputImageUrl);

        builder.setView(layout);

        builder.setPositiveButton("Guardar", (dialog, which) -> {
            mangaItem.setTitle(inputTitle.getText().toString());
            mangaItem.setStatus(inputStatus.getText().toString());
            mangaItem.setType(inputType.getText().toString());
            mangaItem.setImageUrl(inputImageUrl.getText().toString());

            SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
            int userId = prefs.getInt("current_user_id", -1);

            MangaEntity updated = AppDatabase.getInstance(requireContext())
                    .mangaDao().getMangaByTitle(userId, mangaItem.getTitle());
            if (updated != null) {
                updated.title = mangaItem.getTitle();
                updated.status = mangaItem.getStatus();
                updated.imageUrl = mangaItem.getImageUrl();
                AppDatabase.getInstance(requireContext()).mangaDao().updateManga(updated);
                loadMangaFromDatabase();
                filterMangaList(editTextFilter.getText().toString());
            }
        });

        builder.setNegativeButton("Cancelar", null);
        builder.show();
    }

    /**
     * Aplica filtros por estado y búsqueda textual.
     */
    private void filterMangaList(String query) {
        filteredMangaList.clear();
        int count = 0;
        for (AnimeItem manga : fullMangaList) {
            boolean matchesStatus = currentStatus.equals("All") || manga.getStatus().equalsIgnoreCase(currentStatus);
            boolean matchesQuery = manga.getTitle().toLowerCase().contains(query.toLowerCase());
            if (matchesStatus && matchesQuery) {
                filteredMangaList.add(manga);
                count++;
                if (count >= 10) {
                    Toast.makeText(requireContext(), "Mostrando los primeros 10 resultados", Toast.LENGTH_SHORT).show();
                    break;
                }
            }
        }
        adapter.notifyDataSetChanged();
    }

    /**
     * Cambia el modo de presentación del RecyclerView.
     */
    private void setLayoutMode(int mode) {
        currentViewMode = mode;

        if (mode == 2) {
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        } else if (mode == 1) {
            recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 1));
        } else {
            recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        }

        adapter = new MangaAdapter(getContext(), filteredMangaList);
        adapter.setViewMode(mode);
        adapter.setOnMangaRemoveListener(mangaItem -> {
            SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
            int userId = prefs.getInt("current_user_id", -1);
            AppDatabase db = AppDatabase.getInstance(requireContext());
            MangaEntity entity = db.mangaDao().getMangaByTitle(userId, mangaItem.getTitle());
            if (entity != null) db.mangaDao().deleteManga(entity);
            fullMangaList.remove(mangaItem);
            filterMangaList(editTextFilter.getText().toString());
        });
        adapter.setOnMangaEditListener(this::showEditMangaDialog);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

        int defaultTint = ContextCompat.getColor(requireContext(), R.color.textPrimary);
        int activeTint = ContextCompat.getColor(requireContext(), R.color.activeTint);

        buttonGrid.setColorFilter(mode == 0 ? activeTint : defaultTint);
        buttonLarge.setColorFilter(mode == 1 ? activeTint : defaultTint);
        buttonList.setColorFilter(mode == 2 ? activeTint : defaultTint);
    }

    /**
     * Carga la lista completa de mangas desde la base de datos.
     */
    private void loadMangaFromDatabase() {
        fullMangaList.clear();

        SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        int userId = prefs.getInt("current_user_id", -1);

        List<MangaEntity> entities = AppDatabase.getInstance(requireContext()).mangaDao().getMangaByUser(userId);

        for (MangaEntity e : entities) {
            fullMangaList.add(new AnimeItem(e.title, e.imageUrl, 0, 0, 0, "Manga", e.status));
        }

        filteredMangaList.clear();
        filteredMangaList.addAll(fullMangaList);
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("currentStatus", currentStatus);
    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        if (savedInstanceState != null) {
            currentStatus = savedInstanceState.getString("currentStatus", "Reading");
            textViewTitle.setText(currentStatus);
            filterMangaList(editTextFilter.getText().toString());
        }
    }
}
