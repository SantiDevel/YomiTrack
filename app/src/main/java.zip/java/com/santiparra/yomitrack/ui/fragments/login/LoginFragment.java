package com.santiparra.yomitrack.ui.fragments.login;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.santiparra.yomitrack.R;
import com.santiparra.yomitrack.db.AppDatabase;
import com.santiparra.yomitrack.db.entities.UserEntity;
import com.santiparra.yomitrack.ui.MainActivity;

/**
 * Fragmento que gestiona el inicio de sesión y entrada como invitado.
 */
public class LoginFragment extends Fragment {

    private EditText usernameEditText, passwordEditText;
    private Button loginButton, guestButton, registerButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        // Referencias UI
        usernameEditText = view.findViewById(R.id.editTextUsername);
        passwordEditText = view.findViewById(R.id.editTextPassword);
        loginButton = view.findViewById(R.id.buttonLogin);
        guestButton = view.findViewById(R.id.buttonGuest);
        registerButton = view.findViewById(R.id.buttonGoRegister);

        // Botón Login
        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(getContext(), "Rellena todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            AppDatabase db = AppDatabase.getInstance(requireContext());
            UserEntity user = db.userDao().login(username, password);

            if (user != null) {
                saveSession(user.id);
                navigateToHome();
            } else {
                Toast.makeText(getContext(), "Credenciales inválidas", Toast.LENGTH_SHORT).show();
            }
        });

        // Botón Guest
        guestButton.setOnClickListener(v -> {
            saveSession(-1); // usuario invitado
            navigateToHome();
        });

        // Botón para ir a registro
        registerButton.setOnClickListener(v -> {
            NavController navController = NavHostFragment.findNavController(LoginFragment.this);
            navController.navigate(R.id.action_login_to_register);
        });

        return view;
    }

    /**
     * Guarda el ID del usuario actual en SharedPreferences.
     */
    private void saveSession(int userId) {
        SharedPreferences prefs = requireContext().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        prefs.edit().putInt("current_user_id", userId).apply();
    }

    /**
     * Abre la MainActivity y finaliza la actual.
     */
    private void navigateToHome() {
        startActivity(new Intent(getActivity(), MainActivity.class));
        requireActivity().finish();
    }
}
