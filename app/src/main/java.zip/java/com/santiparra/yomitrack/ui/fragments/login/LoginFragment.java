package com.santiparra.yomitrack.ui.fragments.login;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.santiparra.yomitrack.R;
import com.santiparra.yomitrack.api.ApiClient;
import com.santiparra.yomitrack.api.ApiService;
import com.santiparra.yomitrack.db.entities.UserEntity;
import com.santiparra.yomitrack.model.LoginResponse;
import com.santiparra.yomitrack.ui.MainActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginFragment extends Fragment {

    private EditText editUsername, editPassword;
    private Button buttonLogin, buttonGuest;
    private SharedPreferences sharedPreferences;
    private ApiService apiService;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        editUsername = view.findViewById(R.id.editTextUsername);
        editPassword = view.findViewById(R.id.editTextPassword);
        buttonLogin = view.findViewById(R.id.buttonLogin);
        buttonGuest = view.findViewById(R.id.buttonGuest);

        sharedPreferences = requireActivity().getSharedPreferences("user_profile", Context.MODE_PRIVATE);
        apiService = ApiClient.getClient().create(ApiService.class);

        buttonLogin.setOnClickListener(v -> loginUser());
        buttonGuest.setOnClickListener(v -> loginAsGuest());

        return view;
    }

    private void loginUser() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(getContext(), "Campos vacíos", Toast.LENGTH_SHORT).show();
            return;
        }

        UserEntity user = new UserEntity();
        user.setUsername(username);
        user.setPassword(password);

        apiService.loginUser(user).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse loginResponse = response.body();

                    if (loginResponse.isSuccess() && loginResponse.getUser() != null) {
                        int userId = loginResponse.getUser().getId();
                        sharedPreferences.edit().putInt("userId", userId).apply();
                        goToMain();
                    } else {
                        Toast.makeText(getContext(), "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), "Error en la respuesta del servidor", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Toast.makeText(getContext(), "Fallo en la conexión: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void loginAsGuest() {
        sharedPreferences.edit().putInt("userId", 99999).apply();
        sharedPreferences.edit().putString("bio", "").apply();
        sharedPreferences.edit().putBoolean("refresh_profile", true).apply();
        goToMain();
    }

    private void goToMain() {
        Intent intent = new Intent(getActivity(), MainActivity.class);
        startActivity(intent);
        requireActivity().finish();
    }
}
