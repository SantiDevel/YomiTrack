package com.santiparra.yomitrack.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.santiparra.yomitrack.db.dao.AnimeDao;
import com.santiparra.yomitrack.db.dao.MangaDao;
import com.santiparra.yomitrack.db.dao.UserDao;
import com.santiparra.yomitrack.db.entities.AnimeEntity;
import com.santiparra.yomitrack.db.entities.MangaEntity;
import com.santiparra.yomitrack.db.entities.UserEntity;

/**
 * Base de datos principal de la app que maneja entidades de usuarios, anime y manga.
 * Utiliza Room como ORM.
 */
@Database(entities = {UserEntity.class, AnimeEntity.class, MangaEntity.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {

    // Instancia singleton para evitar múltiples accesos simultáneos
    private static volatile AppDatabase INSTANCE;

    /**
     * Retorna una instancia singleton de la base de datos.
     * @param context contexto de aplicación
     * @return instancia de AppDatabase
     */
    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            INSTANCE = Room.databaseBuilder(
                    context.getApplicationContext(),
                    AppDatabase.class,
                    "yomitrack-db"
            ).allowMainThreadQueries().build(); // Solo para pruebas o apps pequeñas
        }
        return INSTANCE;
    }

    // DAOs disponibles
    public abstract UserDao userDao();
    public abstract AnimeDao animeDao();
    public abstract MangaDao mangaDao();
}
