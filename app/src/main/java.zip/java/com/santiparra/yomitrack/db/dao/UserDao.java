package com.santiparra.yomitrack.db.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.santiparra.yomitrack.db.entities.UserEntity;

/**
 * DAO para operaciones relacionadas con usuarios.
 */
@Dao
public interface UserDao {

    /**
     * Inserta un nuevo usuario en la base de datos.
     * @param user objeto usuario
     * @return ID generado
     */
    @Insert
    long insertUser(UserEntity user);

    /**
     * Devuelve un usuario si coinciden username y password.
     * @param username nombre de usuario
     * @param password contraseña
     * @return usuario encontrado o null
     */
    @Query("SELECT * FROM users WHERE username = :username AND password = :password LIMIT 1")
    UserEntity login(String username, String password);
}
